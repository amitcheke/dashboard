import { createContext, useContext, useMemo, useState } from "react"
import useWebSocket from "../services/useWebSocket"
import useFetch from "../services/useFetch"

const VehicleContext =  createContext(null)

export function VehicleProvider({ children }){
    const { message, status } = useWebSocket('wss://case-study-26cf.onrender.com')
    const {loading, data: result} = useFetch('/api/vehicles')
    const lastUpdate = message?.timestamp
    const [statusFilter, setStatusFilter] = useState('all')
    const allVehicles = (message?.data) ? message.data : result?.data ? result.data : []
    

    const vehicleList = useMemo(() => {

        if(statusFilter === 'all') {
            return allVehicles;
        }

        return allVehicles.filter(vehicle => vehicle.status === statusFilter)

    },[statusFilter,allVehicles])

    const value ={
        allVehicles,
        lastUpdate,
        statusFilter,
        setStatusFilter,
        status,
        vehicleList,
        loading,
        status
    }

    return(
        <VehicleContext.Provider value={value}>
            {children}
        </VehicleContext.Provider >
    )

}

export function useVehicle(){
    const context =  useContext(VehicleContext)

    if(!context){
        throw new Error('useVehicle must be used inside VehicleProvider')
    }

    return context
}