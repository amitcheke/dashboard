import { Box, AppBar, Toolbar, Typography } from '@mui/material';
import LocalShippingOutlinedIcon from '@mui/icons-material/LocalShippingOutlined';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import { useVehicle } from '../context/VehicleContext';
import FleetOverview from './FleetOverview';
import VehicleList from './VehicleList';
import VehicleDetailsModal from './VehicleDetailsModal'
import useFetch from '../services/useFetch'
import { useState } from 'react';



function Dashboard() {
    const { statusFilter, vehicleList } = useVehicle()
    const [vehicleId, setVehicleId] = useState(null)
    const [open, setOpen] = useState(false)
    let result = useFetch(vehicleId ? `/api/vehicles/${vehicleId}` : null)

    const showVehicleDetails = (vehicleId) => {
        setVehicleId(vehicleId)
        setOpen(true)
    }

    const handleClose = () => {
        setVehicleId(null)
        result = null
        setOpen(false)
    }
    return (
        <Box sx={{
            display: 'flex',
            flexDirection: 'column',
            height: '100vh'
        }}>
            <AppBar position="static"
                sx={{
                    bgcolor: 'white',
                    color: 'black',
                    boxShadow: 'none',
                    borderBottom: '2px solid lightgray'
                }}
            >
                <Toolbar>
                    <Box sx={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <LocalShippingOutlinedIcon />
                            <Typography variant="h6">Fleet Tracking Dashboard</Typography>
                        </Box>

                        <Typography variant="caption" sx={{ color: 'text.secondary' }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                Real-time vehicle Monitoring<FiberManualRecordIcon sx={{ color: "text.disabled" }} fontSize="12" />LogiNext Case Study
                            </Box>
                        </Typography>

                    </Box>
                </Toolbar>
            </AppBar>
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: { xs: "column", md: 'row' },
                    height: { xs: 'auto', md: '100%' }
                }}>
                <Box
                    sx={{
                        flex: { xs: '1 1 auto', md: '0 0 25%' },
                        '@media (min-width: 900px) and (max-width: 1400px)': { paddingBottom: '20px' },
                        minWidth: 0,
                        width: { xs: '100%', md: 'auto' },
                        height: { xs: 'auto', md: '100%' },
                        overflowY: 'hidden',
                        '@media (max-width: 1400px)': { overflowY: 'auto' },
                        boxSizing: 'border-box'
                    }}>
                    <FleetOverview />
                </Box>
                <Box
                    sx={{
                        flex: 1,
                        minWidth: 0,
                        width: { xs: '100%', md: 'auto' }
                    }}>

                    <VehicleList
                        showVehicleDetails={showVehicleDetails}
                        vehicleList={vehicleList}
                        status={statusFilter}
                    />
                </Box>
            </Box>
            <VehicleDetailsModal
                open={open && result?.data} handleClose={handleClose}
                vehicleDetails={result?.data ? result.data.data : null}
                loading={result.loading}
            />
        </Box>
    );
}

export default Dashboard;