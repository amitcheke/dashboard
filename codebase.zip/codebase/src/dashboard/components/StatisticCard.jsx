import React from 'react';
import { Card, CardContent, Typography, Box } from '@mui/material';
function StatisticCard({ title, value, icon }) {
    return (
        <Card variant='outlined' sx={{ flex: 1, borderRadius: 4 }}>
            <CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <Typography sx={{ fontWeight: 'bold' }} variant='h6'>{value}</Typography>
                <Box sx={{ display: 'flex', gap: 1, color: "text.secondary", alignItems: 'center' }}>
                    {icon}
                    <Typography variant='body2' sx={{ color: "text.secondary" }}>{title}</Typography>
                </Box>
            </CardContent>
        </Card>
    )
}

export default StatisticCard