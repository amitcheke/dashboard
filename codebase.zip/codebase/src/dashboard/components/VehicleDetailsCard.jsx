import { Box, Typography } from "@mui/material";

function VehicleDetailsCard({ title, icon, content, children }) {
    return <Box
        sx={{
            flex: 1,
            borderLeft: "5px solid blue",
            borderRadius: 3,
            bgcolor: "grey.50",
            p: 2
        }}
    >
        <Box sx={{ display: "flex", alignItems: 'center', gap: 1 }}>
            {icon}
            <Typography 
                sx={{ color: 'text.secondary', fontSize: '0.8rem' }}
            >
                {title}
            </Typography>
        </Box>
        <Typography variant="body1"
            sx={{ color: 'text.primary', mt: 0.5, mb: 0.75, fontWeight: 700 }}
        >
            {content}
        </Typography>
        {children}
    </Box>
}

export default VehicleDetailsCard