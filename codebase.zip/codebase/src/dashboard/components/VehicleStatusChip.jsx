import { Box } from "@mui/material"
import { STATUS_CONFIG } from "../../constants/constants"

function VehicleStatusChip({ status, showIcon = false }) {

    return (<Box
        sx={{
            display: 'inline-flex',
            alignItems: 'center',
            borderRadius: 5,
            backgroundColor: STATUS_CONFIG[status].bgColor,
            color: STATUS_CONFIG[status].color
        }}>

        <Box sx={{
            display: 'flex', alignItems: 'center', gap: 1, width: 'max-content', fontSize: "0.875rem",
            fontWeight: 700, px: 2, py: 0.3
        }}>
            {showIcon && STATUS_CONFIG[status].icon}
            {STATUS_CONFIG[status].label}
        </Box>
    </Box>)

}

export default VehicleStatusChip