import { VEHICLE_SPEED_CONFIG } from "../../constants/constants"
import { Box, Typography } from "@mui/material"

function VehicleSpeedChip({ speed }) {
    return <Box
        sx={{
            display: 'inline-flex',
            alignItems: 'center',
            borderRadius: 2,
            backgroundColor: VEHICLE_SPEED_CONFIG.bgColor,
            color: VEHICLE_SPEED_CONFIG.color,
            width: 'max-content',
        }}>
        <Typography variant="body2"
            sx={{
                fontWeight: 700,
                px:1, py: 0.3
            }}>
            {speed} mph
        </Typography>
    </Box>
}

export default VehicleSpeedChip