import { useVehicle } from '../../context/VehicleContext';
import { useState, useEffect } from 'react';
import { Box, Typography } from '@mui/material';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import QueryBuilderOutlinedIcon from '@mui/icons-material/QueryBuilderOutlined';



const UPDATE_INTERVAL = 3 * 60 * 1000; // 3 minutes

function NextUpdateStatus() {
    const [now, setNow] = useState(new Date())
    const { lastUpdate, loading } = useVehicle()
    const lastupdated = lastUpdate ? new Date(lastUpdate) : null


    useEffect(() => {
        const interval = setInterval(() => {
            setNow(new Date())
        }, 1000)

        return () => clearInterval(interval)
    }, [])

    const elapsedTime = Math.max(0, now - lastupdated)

    const timeUntilNextUpdate = Math.max(0, UPDATE_INTERVAL - elapsedTime)

    const formatTime = (seconds) => {
        if (seconds < 60) {
            return `~${seconds}s`
        }

        const minutes = Math.ceil(seconds / 60)

        return minutes === 1 ? `~${minutes} minute` : `~${minutes} minutes`

    }

    const formatLastUpdatedTime = (seconds) => {
        if (seconds < 60) {
            return `${seconds}s`
        }

        const minutes = Math.floor(seconds / 60)

        return minutes === 1 ? `${minutes} minute` : `${minutes} minutes`

    }
    if (loading || !lastupdated) {
        return null
    }

    return (
        <Box sx={{ display: 'flex', 
        p: 1, 
        border: '1px solid lightgray', 
        borderRadius: 2, 
        backgroundColor: 'grey.100', 
        justifyContent: 'center', 
        alignItems: 'center' }}>

            <Typography variant='caption'>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <QueryBuilderOutlinedIcon sx={{ color: "text.disabled", pr: 1, fontSize: "16px" }} />
                    Updated {formatLastUpdatedTime(Math.floor(elapsedTime / 1000))} ago<FiberManualRecordIcon
                        sx={{
                            color: "text.disabled"
                        }}
                        fontSize="12" />
                    Next Update in {formatTime(Math.ceil(timeUntilNextUpdate / 1000))}
                </Box>
            </Typography>
        </Box>
    );
}

export default NextUpdateStatus;