import { Box, Paper, Link, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material"
import formatDate from "../utils/formatDateUtil"
import VehicleStatusChip from './components/VehicleStatusChip'
import VehicleSpeedChip from './components/VehicleSpeedChip'

function VehicleList({showVehicleDetails, vehicleList, status }) {
    
    if (status === "Error") return <Box>Error in fetching the data</Box>


    return <Box>
        <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}><Typography variant="h6">Vehiles ({vehicleList.length})</Typography></Box>
        <TableContainer
            component={Paper}
            sx={{
                maxHeight: '81vh',
                height: '81vh',
                overflowY: 'auto'
            }}
        >
            <Table stickyHeader >
                <TableHead sx={{ 
                    "& .MuiTableCell-root": {
                    fontWeight: 'bold',
                    bgcolor: 'grey.100',
                }
                 }}>
                    <TableRow>
                        <TableCell sx={{fontWeight: 'bold'}}>Vehicle</TableCell>
                        <TableCell sx={{fontWeight: 'bold'}}>Drive</TableCell>
                        <TableCell sx={{fontWeight: 'bold'}}>Status</TableCell>
                        <TableCell sx={{fontWeight: 'bold'}}>Speed</TableCell>
                        <TableCell sx={{fontWeight: 'bold'}}>Destination</TableCell>
                        <TableCell sx={{fontWeight: 'bold'}}>ETA</TableCell>
                        <TableCell sx={{fontWeight: 'bold'}}>Last Update</TableCell>
                        <TableCell sx={{fontWeight: 'bold'}}>Location</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {vehicleList && vehicleList.map((r) => <TableRow key={r.id}>
                        <TableCell><Link component={"button"} onClick={() => showVehicleDetails(r.id)} >{r.vehicleNumber}</Link></TableCell>
                        <TableCell>{r.driverName}</TableCell>
                        <TableCell><VehicleStatusChip status={r.status}/></TableCell>
                        <TableCell><VehicleSpeedChip speed={r.speed}/></TableCell>
                        <TableCell>{r.destination}</TableCell>
                        <TableCell>{formatDate(r.estimatedArrival) || '-'}</TableCell>
                        <TableCell>{formatDate(r.lastUpdated)}</TableCell>
                        <TableCell>{`${r.currentLocation.lat.toFixed(4)}, ${r.currentLocation.lng.toFixed(4)}`}</TableCell>
                    </TableRow>)}
                </TableBody>
            </Table>
        </TableContainer>
    </Box>
}

export default VehicleList