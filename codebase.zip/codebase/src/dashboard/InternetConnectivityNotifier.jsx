import React, { useState, useEffect } from 'react';
import { Box, Typography } from '@mui/material';
import WifiIcon from '@mui/icons-material/Wifi';
import { useVehicle } from '../context/VehicleContext';

function InternetConnectivityNotifier() {
    const { status } = useVehicle()
    const [isOnline, setIsOnline] = useState(navigator.onLine || status !== "Connected");

    useEffect(() => {
        const handleOnline = () => setIsOnline(true);
        const handleOffline = () => setIsOnline(false);

        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);

        return () => {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, []);

    return <Box
        sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 1,
            justifyContent: 'center',
            border: '1px solid lightgray',
            borderRadius: 2,
            p: 1,
            paddingRight: 2,
            paddingLeft: 2,
            color: isOnline ? 'green' : 'error.main'
        }}>
        <WifiIcon
            sx={{
                fontSize: 18,
                color: isOnline ? 'green' : 'error.main'
            }} />
        <Typography variant="body1">
            {isOnline ? 'Live Updates Active' : 'Live Updates Inactive'}
        </Typography>
    </Box>

}

export default InternetConnectivityNotifier