
import { Box, Divider } from '@mui/material';
import Filters from './Filters';
import Statistics from './Statistics';
import { useVehicle } from '../context/VehicleContext';
import getStatusCount from '../utils/getStatusCountUtil'
import formatTime from '../utils/formatTimeUtil';
import NextUpdateStatus from './components/NextUpdateStatus'
import InternetConnectivityNotifier from './InternetConnectivityNotifier';
import calculateAverageSpeed from '../utils/calculateAverageSpeedUtil';

function FleetOverview() {
    const { allVehicles, lastUpdate } = useVehicle()
    const statusCount = getStatusCount(allVehicles)
    const avgSpeed = calculateAverageSpeed(allVehicles);

    return (
        <Box
            sx={{
                p: 2,
                borderRight: '2px solid',
                borderColor: 'divider',
                height: '100%',
            }}>
            <InternetConnectivityNotifier />
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <Filters statusCount={statusCount} />
                <Divider />
                <Statistics
                    totalVehicles={allVehicles.length}
                    avgSpeed={avgSpeed}
                    lastUpdate={formatTime(lastUpdate)}
                    movingVehicles={statusCount.en_route}
                />
                <NextUpdateStatus />
            </Box>
        </Box>
    );
}

export default FleetOverview;