import { Box, LinearProgress, Typography } from "@mui/material";
import Modal from "@mui/material/Modal";
import VehicleDetailsCard from "./components/VehicleDetailsCard"
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import formatDate from "../utils/formatDateUtil"
import IconButton from '@mui/material/IconButton';
import Divider from '@mui/material/Divider';
import CloseIcon from '@mui/icons-material/Close';
import PersonOutlinedIcon from '@mui/icons-material/PersonOutlined';
import LocalShippingOutlinedIcon from '@mui/icons-material/LocalShippingOutlined';
import NearMeOutlinedIcon from '@mui/icons-material/NearMeOutlined';
import SpeedOutlinedIcon from '@mui/icons-material/SpeedOutlined';
import PhoneOutlinedIcon from '@mui/icons-material/PhoneOutlined';
import PlaceOutlinedIcon from '@mui/icons-material/PlaceOutlined';
import Battery0BarRoundedIcon from '@mui/icons-material/Battery0BarRounded';
import LocalGasStationRoundedIcon from '@mui/icons-material/LocalGasStationRounded';
import AccessTimeRoundedIcon from '@mui/icons-material/AccessTimeRounded';
import { STATUS_CONFIG } from "../constants/constants";
import { progressBarColor } from "../utils/getProgressBarColorUtil";
import VehicleStatusChip from "./components/VehicleStatusChip";

function VehicleDetailsModal({ open, handleClose, vehicleDetails, loading }) {


    if (!vehicleDetails) return null

    return (<Modal open={open} onClose={handleClose}>
        {loading ? (
            <Box sx={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: "translate(-50%, -50%)",
                width: { xs: '95%', sm: 600 },
                bgcolor: "white",
                p: { xs: 2, sm: 3 },
                borderRadius: 2,
                boxShadow: 24
            }}>
                <LinearProgress />
            </Box>
        ) : (
            <Box
                sx={{
                    position: 'absolute',
                    top: '50%',
                    left: '50%',
                    transform: "translate(-50%, -50%)",
                    width: { xs: '95%', sm: 600 },
                    bgcolor: "white", p: { xs: 2, sm: 3 },
                    borderRadius: 2,
                    boxShadow: 24
                }}>
                <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
                    <Box sx={{
                        display: 'flex',
                        flexDirection: 'column'
                    }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <LocalShippingOutlinedIcon />
                            <Typography variant="h6" sx={{ color: 'text.primary', fontWeight: 700 }}>
                                {vehicleDetails.vehicleNumber}
                            </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                <PersonOutlinedIcon sx={{ color: "text.secondary" }} />
                                <Typography sx={{ color: 'text.secondary' }} variant="body1">{vehicleDetails.driverName}</Typography>
                            </Box>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                <FiberManualRecordIcon sx={{ color: STATUS_CONFIG[vehicleDetails.status].color }} fontSize="4" />
                                <Typography sx={{ color: 'text.secondary' }} variant="body1">{STATUS_CONFIG[vehicleDetails.status].label}</Typography>
                            </Box>
                        </Box>
                    </Box>
                    <Box><IconButton onClick={handleClose}><CloseIcon /></IconButton></Box>
                </Box>
                <Divider sx={{ mb: 2 }} />
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <Box sx={{ display: 'flex', gap: 2 }}>
                        <VehicleDetailsCard
                            title={"STATUS"}
                            icon={<NearMeOutlinedIcon sx={{ fontSize: '1rem', color: 'text.secondary' }} />}
                            content={<VehicleStatusChip status={vehicleDetails.status} showIcon />}
                        />
                        <VehicleDetailsCard
                            title={"CURRENT SPEED"}
                            icon={<SpeedOutlinedIcon sx={{ fontSize: '1rem', color: 'text.secondary' }} />}
                            content={vehicleDetails.speed}
                        />
                    </Box>

                    <Box sx={{ display: 'flex', gap: 2 }}>
                        <VehicleDetailsCard
                            title={"DRIVER"}
                            icon={<PersonOutlinedIcon sx={{ fontSize: '1rem', color: 'text.secondary' }} />}
                            content={vehicleDetails.driverName}
                        />
                        <VehicleDetailsCard
                            title={"PHONE"}
                            icon={<PhoneOutlinedIcon sx={{ fontSize: '1rem', color: 'text.secondary' }} />}
                            content={vehicleDetails.driverPhone}
                        />
                    </Box>

                    <Box sx={{ display: 'flex', gap: 2 }}>
                        <VehicleDetailsCard
                            title={"DESTINATION"}
                            icon={<PlaceOutlinedIcon sx={{ fontSize: '1rem', color: 'text.secondary' }} />}
                            content={vehicleDetails.destination}
                        />
                        <VehicleDetailsCard
                            title={"LOCATION"}
                            icon={<NearMeOutlinedIcon sx={{ fontSize: '1rem', color: 'text.secondary' }} />}
                            content={`${vehicleDetails.currentLocation.lat.toFixed(6)}, ${vehicleDetails.currentLocation.lng.toFixed(6)}`}
                        />
                    </Box>

                    <Box sx={{ display: 'flex', gap: 2 }}>
                        <VehicleDetailsCard
                            title={"BATTERY LEVEL"}
                            icon={<Battery0BarRoundedIcon sx={{ fontSize: '1rem', color: 'text.secondary' }} />}
                            content={`${vehicleDetails.batteryLevel}%`} >
                            <LinearProgress
                                color={progressBarColor(vehicleDetails.batteryLevel)}
                                variant="determinate"
                                value={vehicleDetails.batteryLevel}
                                sx={{ height: 10, borderRadius: 5, mt: 1 }}
                            />
                        </VehicleDetailsCard>

                        <VehicleDetailsCard
                            title={"FUEL LEVEL"}
                            icon={<LocalGasStationRoundedIcon sx={{ fontSize: '1rem', color: 'text.secondary' }} />}
                            content={`${vehicleDetails.fuelLevel}%`} >
                            <LinearProgress
                                color={progressBarColor(vehicleDetails.fuelLevel)}
                                variant="determinate"
                                value={vehicleDetails.fuelLevel}
                                sx={{ height: 10, borderRadius: 5, mt: 1 }}
                            />
                        </VehicleDetailsCard>
                    </Box>

                    <Box sx={{ display: 'flex', gap: 2 }}>
                        <Box sx={{ width: '50%', pr: 2 }}>
                            <VehicleDetailsCard
                                title={"LAST UPDATED"}
                                icon={<AccessTimeRoundedIcon sx={{ fontSize: '1rem', color: 'text.secondary' }} />}
                                content={formatDate(vehicleDetails.lastUpdated)}
                            />
                        </Box>
                    </Box>
                </Box>
            </Box>)}
    </Modal>)

}

export default VehicleDetailsModal