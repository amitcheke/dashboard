import { ToggleButton, Typography, Box, ToggleButtonGroup } from '@mui/material';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import MonitorHeartOutlinedIcon from '@mui/icons-material/MonitorHeartOutlined';
import { useVehicle } from '../context/VehicleContext';

function Filters({ statusCount }) {
    const { statusFilter, setStatusFilter } = useVehicle();
    const handleStatusChange = (event, newStatus) => {
        setStatusFilter(newStatus ? newStatus : 'all');
    };
    return (
        <Box>
            <Box
                sx={{
                    py: 2,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1
                }}>
                <MonitorHeartOutlinedIcon sx={{ fontSize: 18 }} />
                <Typography variant='body2' sx={{ fontWeight: 'bold' }}>Filters By Status</Typography>
            </Box>
            <ToggleButtonGroup sx={{
                display: 'flex',
                flexWrap: "wrap",
                gap: 1,
                width: '100%',

                "& .MuiToggleButtonGroup-grouped": {
                    border: 1,
                    borderRadius: "8px !important",
                    minWidth: '140px',
                    flex: "1 1 calc(50% - 4px)",
                    textTransform: 'capitalize',
                    justifyContent: 'flex-start',
                    fontSize: '0.875rem',

                },

                "& .MuiToggleButton-root.Mui-selected": {
                    backgroundColor: "transparent",
                },

                "& .MuiToggleButton-root.Mui-selected:hover": {
                    backgroundColor: "transparent",
                },
            }}
                color="primary"
                exclusive
                value={statusFilter}
                onChange={handleStatusChange}
            >
                <ToggleButton size="small" value="all">
                    <FiberManualRecordIcon sx={{ color: "text.disabled", pr: 1 }} fontSize="12" />
                    All (<Typography sx={{ fontWeight: 'bold' }} variant="body2">{statusCount.all}</Typography>)
                </ToggleButton>
                <ToggleButton size="small" value="idle">
                    <FiberManualRecordIcon sx={{ color: "text.disabled", pr: 1 }} fontSize="12" />
                    Idle (<Typography sx={{ fontWeight: 'bold' }} variant="body2">{statusCount.idle}</Typography>)
                </ToggleButton>
                <ToggleButton size="small" value="en_route">
                    <FiberManualRecordIcon sx={{ color: "info.main", pr: 1 }} fontSize="12" />
                    En Route (<Typography sx={{ fontWeight: 'bold' }} variant="body2">{statusCount.en_route}</Typography>)
                </ToggleButton>
                <ToggleButton size="small" value="delivered">
                    <FiberManualRecordIcon sx={{ color: "success.main", pr: 1 }} fontSize="12" />Delivered (<Typography sx={{ fontWeight: 'bold' }} variant="body2">{statusCount.delivered}</Typography>)</ToggleButton>
            </ToggleButtonGroup>
        </Box>
    );
}

export default Filters;