import { Box, Typography } from '@mui/material';
import GroupOutlinedIcon from '@mui/icons-material/GroupOutlined';
import QueryBuilderOutlinedIcon from '@mui/icons-material/QueryBuilderOutlined';
import TrendingUpOutlinedIcon from '@mui/icons-material/TrendingUpOutlined';
import MonitorHeartOutlinedIcon from '@mui/icons-material/MonitorHeartOutlined';
import StatisticCard from './components/StatisticCard';


function Statistics({ totalVehicles, avgSpeed, lastUpdate, movingVehicles }) {
    return (
        <Box>
            <Box
                sx={{
                    paddingBottom: 2,
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: 1
                }}>
                <QueryBuilderOutlinedIcon sx={{ fontSize: 18 }} />
                <Typography variant='body2' sx={{ fontWeight: 'bold' }}>Fleet Statistics</Typography>
            </Box>
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 2
                }}>
                <Box sx={{
                    "& .MuiCardContent-root": {
                        p: 1,
                        "&:last-child": {
                            pb: 1
                        }
                    },
                    display: 'flex',
                    flexDirection: 'row',
                    "@media (max-width:1399px)": { flexDirection: 'column' },
                    gap: 2,
                    width: '100%'
                }}>
                    <StatisticCard title="TOTAL FLEET" value={totalVehicles} icon={<GroupOutlinedIcon />} />
                    <StatisticCard title="AVG SPEED" value={avgSpeed} icon={<TrendingUpOutlinedIcon />} />
               
                </Box>
                <Box
                    sx={{
                        display: 'flex',
                        flexDirection: 'row',
                        "@media (max-width:1399px)": { flexDirection: 'column' },
                        gap: 2,
                        width: '100%',
                        "& .MuiCardContent-root": {
                            p: 1,
                            "&:last-child": {
                                pb: 1
                            }
                        }
                    }}>
                    <StatisticCard title="MOVING" value={movingVehicles} icon={<MonitorHeartOutlinedIcon />} />
                    <StatisticCard title="LAST UPDATE" value={lastUpdate} icon={<QueryBuilderOutlinedIcon />} />    
              
                </Box>
            </Box>
        </Box>
    );
}

export default Statistics;