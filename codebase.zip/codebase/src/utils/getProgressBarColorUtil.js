  export const progressBarColor = (value) =>{
        if(value < 20) return "error"
        if(value < 50) return "warning"
        return "success"

    }