function formatDate(dateStr){
    if(!dateStr) return '';
    const date = new Date(dateStr)

    if(Number.isNaN(date.getTime())){
        return 'Invalid Date'
    }

    return new Intl.DateTimeFormat('en-GB', {
        day:'2-digit',
        month:'2-digit',
        year:'numeric',
        hour:'2-digit',
        minute:'2-digit',
        second:'2-digit',
        hour12:false
    }).format(date)

}

export default formatDate