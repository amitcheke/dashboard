function getStatusCount(vehicleList){
    const statusData = {
        'all': vehicleList.length,
        'delivered':0,
        'idle':0,
        'en_route':0
    }
    vehicleList.forEach(element => {
        
        statusData[element.status] += 1 
    });
    return statusData
}

export default getStatusCount