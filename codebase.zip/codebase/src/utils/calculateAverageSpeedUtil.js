function calculateAverageSpeed(vehicles) {
    if (vehicles.length === 0) return 0;
    const totalSpeed = vehicles.reduce((sum, vehicle) => sum + vehicle.speed, 0);
    return Math.round(totalSpeed / vehicles.length);
}

export default calculateAverageSpeed;