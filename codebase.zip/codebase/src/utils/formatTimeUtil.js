function formatTime(dateStr){
    if(!dateStr) return '';
    const date = new Date(dateStr)

    if(Number.isNaN(date.getTime())){
        return 'Invalid Date'
    }

    return new Intl.DateTimeFormat('en-GB', {
        hour:'2-digit',
        minute:'2-digit',
        hour12:false
    }).format(date)

}

export default formatTime