import { useEffect, useState } from "react";
const BASE_URL = 'https://case-study-26cf.onrender.com'

function useFetch(url) {
    const [data, setData] = useState(null)
    const [loading, setLoading] = useState(null)
    const [error, setError] = useState(null)

    useEffect(() => {
        if(!url) return
        
        setLoading(true)

        async function fetchData() {
            try {
                setLoading(true)
                setError(null)

                const response = await fetch(`${BASE_URL}${url}`)

                if (!response.ok) {
                    throw new Error('Failed to fetch data')
                }

                const result = await response.json()
                setData(result)

            } catch (error) {
                setError(error.message)
            } finally {
                setLoading(false)
            }
        }
        fetchData()
    }, [url])

    return {loading, error, data}
}

export default useFetch