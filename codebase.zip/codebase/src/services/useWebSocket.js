import { useEffect, useRef, useState } from "react"

function useWebSocket(url){
    const socketRef = useRef(null)
    const [message, setMessage] = useState(null)
    const [status, setStatus] = useState('Connecting')

    useEffect(()=>{
        const socket = new WebSocket(url)
        socketRef.current =  socket

        socket.addEventListener('open', () => {
            setStatus('Connected')
        })

        socket.addEventListener('message', (event)=>{
            setMessage(JSON.parse(event.data))
        })

        socket.addEventListener('error', ()=>{
            setStatus('Error')
        })

        socket.addEventListener('close', ()=>{
            setStatus('Disconnected')
        })

        return () => {
            socket.close()
            socketRef.current = null
        }

    },[url])

    return {message, status}
}

export default useWebSocket