import AccessTimeRoundedIcon from '@mui/icons-material/AccessTimeRounded';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import NearMeOutlinedIcon from '@mui/icons-material/NearMeOutlined';

export const STATUS_CONFIG = {
    idle: { color: "text.primary", label: "IDLE", bgColor: "#EEEEEE", icon: <AccessTimeRoundedIcon sx={{ fontSize: '1rem', color: 'text.primary' }} /> },
    en_route: { color: "info.dark", label: "EN ROUTE", bgColor: "#BBDEFB", icon: <NearMeOutlinedIcon sx={{ fontSize: '1rem', color: 'info.dark' }} /> },
    delivered: { color: "success.light", label: "DELIVERED", bgColor: "#C8E6C9", icon: <CheckBoxIcon sx={{ fontSize: '1rem', color: 'success.light' }} /> },
}

export const VEHICLE_SPEED_CONFIG = { color: "text.primary", bgColor: "#EEEEEE" }

